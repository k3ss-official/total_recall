# Total Recall Backend API Design

## Overview

This document outlines the design for the Total Recall backend API, which enables users to extract, process, and prepare their ChatGPT conversation history for injection into GPT-4o's persistent memory feature.

## Architecture

The backend API follows a modular, production-grade architecture with these key components:

1. **FastAPI Application** - Provides the HTTP interface for all endpoints
2. **Scraper Module** - Extracts conversation history using the user's OpenAI token
3. **Processing Pipeline** - Uses crawl4ai for conversation processing, formatting, and chunking
4. **Status Tracker** - Monitors and reports on scraping and processing operations
5. **Storage Manager** - Handles saving and retrieving conversation data and processed chunks

## API Endpoints

### 1. POST /api/scrape

Extracts the user's entire conversation history from ChatGPT.

**Request:**
```json
{
  "openai_token": "string",
  "date_filter": "pre_may_8_2025_only" | "all_chats"
}
```

**Response:**
```json
{
  "task_id": "string",
  "status": "pending",
  "message": "Scraping initiated"
}
```

**Implementation Details:**
- Accepts the user's OpenAI token for authentication with ChatGPT
- Uses browser automation techniques to extract conversations
- Saves each conversation as a separate JSON file with title, timestamp, tags, and messages
- Runs as a background task to prevent blocking
- Updates status in real-time for frontend monitoring

### 2. POST /api/process

Processes scraped conversations using crawl4ai for formatting, cleaning, and chunking.

**Request:**
```json
{
  "conversation_ids": ["string"],
  "config": {
    "chunking": {
      "chunk_size": 3900,
      "chunk_overlap": 100
    },
    "include_metadata": true,
    "add_recall_markers": true
  }
}
```

**Response:**
```json
{
  "task_id": "string",
  "status": "pending",
  "message": "Processing initiated"
}
```

**Implementation Details:**
- Uses crawl4ai for the processing pipeline
- Follows the ingest → transform → chunk workflow
- Uses chat_clean.yaml for formatting and cleanup
- Chunks conversations into ~3900-token segments
- Adds recall markers to formatted conversations
- Outputs JSONL or per-chunk JSON files to /output_chunks/
- Runs as a background task with progress tracking

### 3. GET /api/status

Returns the current state of scraping and processing operations.

**Request Parameters:**
- `task_id` (optional): Specific task to check
- `type` (optional): Filter by task type ("scrape" or "process")

**Response:**
```json
{
  "scrape": {
    "status": "completed" | "in_progress" | "failed",
    "conversations_found": 120,
    "date_range": {
      "earliest": "2023-01-15T00:00:00Z",
      "latest": "2025-05-07T23:59:59Z"
    },
    "files": ["conversation_1.json", "conversation_2.json"],
    "errors": []
  },
  "process": {
    "status": "completed" | "in_progress" | "failed",
    "conversations_processed": 120,
    "chunks_created": 350,
    "output_directory": "/output_chunks/",
    "errors": []
  },
  "tasks": [
    {
      "task_id": "string",
      "type": "scrape" | "process",
      "status": "pending" | "in_progress" | "completed" | "failed",
      "progress": 0.75,
      "message": "Processing conversation 90/120",
      "created_at": "2025-05-19T10:30:00Z",
      "updated_at": "2025-05-19T10:35:00Z"
    }
  ]
}
```

## Data Models

### Conversation JSON Format
```json
{
  "id": "string",
  "title": "string",
  "timestamp": "2025-04-07T13:00:00Z",
  "tags": ["string"],
  "conversation": [
    {
      "role": "user" | "assistant",
      "content": "string"
    }
  ]
}
```

### Processed Chunk Format
```json
{
  "chunk_id": "string",
  "conversation_id": "string",
  "metadata": {
    "title": "string",
    "date": "2025-04-07T13:00:00Z",
    "tags": ["string"]
  },
  "content": "string",
  "token_count": 3850
}
```

## Formatting Requirements

All processed conversations will include recall markers:

```markdown
## RECALL MARKER START
Title: {conversation_title}
Date: {conversation_timestamp}
Tags: {comma_separated_tags}
## RECALL MARKER END

User: {message_content}
Assistant: {message_content}
```

## Implementation Plan

1. Create the FastAPI application structure
2. Implement the scraper module with browser automation
3. Set up crawl4ai integration with chat_clean.yaml
4. Implement the processing pipeline
5. Create the status tracking system
6. Add error handling and logging
7. Test the complete pipeline end-to-end
