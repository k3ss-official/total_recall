"""
Total Recall - Format Validator Module

This module validates the formatting of processed conversations and chunks
to ensure they include the required recall markers and follow the specification.
"""

import os
import json
import logging
import re
from typing import Dict, List, Any, Optional, Tuple

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
)
logger = logging.getLogger("total_recall.validator")

# Constants
OUTPUT_DIR = "/home/ubuntu/total_recall/memory/output_chunks"

class FormatValidator:
    """Validates the formatting of processed conversations and chunks."""
    
    def __init__(self):
        """Initialize the validator."""
        pass
    
    def validate_chunk(self, chunk_data: Dict[str, Any]) -> Tuple[bool, List[str]]:
        """
        Validate a chunk's formatting.
        
        Args:
            chunk_data: Chunk data to validate
            
        Returns:
            Tuple of (is_valid, list_of_errors)
        """
        errors = []
        
        # Check required fields
        required_fields = ["chunk_id", "conversation_id", "metadata", "content", "token_count"]
        for field in required_fields:
            if field not in chunk_data:
                errors.append(f"Missing required field: {field}")
        
        # If any required fields are missing, return early
        if errors:
            return False, errors
        
        # Check metadata
        metadata = chunk_data.get("metadata", {})
        metadata_fields = ["title", "date", "tags"]
        for field in metadata_fields:
            if field not in metadata:
                errors.append(f"Missing metadata field: {field}")
        
        # Check content for recall markers
        content = chunk_data.get("content", "")
        if not self._has_recall_markers(content):
            errors.append("Content does not contain recall markers")
        
        # Check token count
        token_count = chunk_data.get("token_count", 0)
        if token_count > 4000:
            errors.append(f"Token count exceeds 4000: {token_count}")
        
        # Check conversation format
        if not self._has_conversation_format(content):
            errors.append("Content does not follow the User/Assistant conversation format")
        
        return len(errors) == 0, errors
    
    def _has_recall_markers(self, content: str) -> bool:
        """
        Check if content has recall markers.
        
        Args:
            content: Content to check
            
        Returns:
            True if content has recall markers, False otherwise
        """
        start_marker = "## RECALL MARKER START"
        end_marker = "## RECALL MARKER END"
        
        return start_marker in content and end_marker in content
    
    def _has_conversation_format(self, content: str) -> bool:
        """
        Check if content follows the User/Assistant conversation format.
        
        Args:
            content: Content to check
            
        Returns:
            True if content follows the format, False otherwise
        """
        # Skip the recall markers section
        parts = content.split("## RECALL MARKER END")
        if len(parts) < 2:
            return False
        
        conversation_part = parts[1].strip()
        
        # Check for at least one User: and one Assistant: pattern
        user_pattern = r"User:"
        assistant_pattern = r"Assistant:"
        
        return (re.search(user_pattern, conversation_part) is not None and 
                re.search(assistant_pattern, conversation_part) is not None)
    
    def validate_all_chunks(self) -> Dict[str, Any]:
        """
        Validate all chunks in the output directory.
        
        Returns:
            Validation results
        """
        results = {
            "total_chunks": 0,
            "valid_chunks": 0,
            "invalid_chunks": 0,
            "errors": {}
        }
        
        # Get all chunk files
        chunk_files = [f for f in os.listdir(OUTPUT_DIR) if f.endswith(".json")]
        results["total_chunks"] = len(chunk_files)
        
        # Validate each chunk
        for chunk_file in chunk_files:
            file_path = os.path.join(OUTPUT_DIR, chunk_file)
            
            try:
                # Load the chunk
                with open(file_path, "r") as f:
                    chunk_data = json.load(f)
                
                # Validate the chunk
                is_valid, errors = self.validate_chunk(chunk_data)
                
                if is_valid:
                    results["valid_chunks"] += 1
                else:
                    results["invalid_chunks"] += 1
                    results["errors"][chunk_file] = errors
                    
            except Exception as e:
                results["invalid_chunks"] += 1
                results["errors"][chunk_file] = [f"Failed to validate: {str(e)}"]
        
        return results


def validate_formatting() -> Dict[str, Any]:
    """
    Validate the formatting of all processed chunks.
    
    Returns:
        Validation results
    """
    validator = FormatValidator()
    return validator.validate_all_chunks()
