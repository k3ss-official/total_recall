"""
Total Recall - API Endpoints for Processing

This module implements the /process endpoint for processing conversations
using crawl4ai for formatting, cleaning, and chunking.
"""

from fastapi import APIRouter, BackgroundTasks, Depends, HTTPException
from pydantic import BaseModel, Field
import asyncio
import logging
from typing import Optional, Dict, Any, List

from backend.processor import process_conversations
from backend.task_manager import task_manager

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
)
logger = logging.getLogger("total_recall.api.process")

# Define router
router = APIRouter(tags=["processing"])

# Request and response models
class ChunkingConfig(BaseModel):
    """Configuration for chunking conversations."""
    chunk_size: int = Field(3900, description="Maximum token size per chunk")
    chunk_overlap: int = Field(100, description="Token overlap between chunks")

class ProcessingConfig(BaseModel):
    """Configuration for processing conversations."""
    chunking: ChunkingConfig = Field(default_factory=ChunkingConfig)
    include_metadata: bool = Field(True, description="Include metadata in chunks")
    add_recall_markers: bool = Field(True, description="Add recall markers to chunks")

class ProcessRequest(BaseModel):
    """Request model for the process endpoint."""
    conversation_ids: List[str] = Field(..., description="List of conversation IDs to process")
    config: ProcessingConfig = Field(default_factory=ProcessingConfig)

class TaskResponse(BaseModel):
    """Response model for task creation."""
    task_id: str = Field(..., description="Unique task identifier")
    status: str = Field(..., description="Task status")
    message: str = Field(..., description="Status message")

async def _run_process_task(task_id: str, conversation_ids: List[str], config: Dict[str, Any]):
    """
    Background task to run the conversation processor.
    
    Args:
        task_id: Task ID for status tracking
        conversation_ids: List of conversation IDs to process
        config: Processing configuration
    """
    try:
        # Update task status to in_progress
        task_manager.update_task(
            task_id, 
            {
                "status": "in_progress",
                "message": "Starting conversation processing"
            }
        )
        
        # Run the processor
        status = await process_conversations(conversation_ids, config)
        
        # Update task with processor results
        task_manager.update_task(
            task_id,
            {
                "status": status["status"],
                "progress": status["progress"],
                "message": status["message"],
                "conversations_processed": status.get("conversations_processed", 0),
                "chunks_created": status.get("chunks_created", 0),
                "output_directory": status.get("output_directory"),
                "errors": status.get("errors", [])
            }
        )
        
    except Exception as e:
        logger.error(f"Process task {task_id} failed: {str(e)}")
        task_manager.update_task(
            task_id,
            {
                "status": "failed",
                "message": f"Processing failed: {str(e)}",
                "errors": [str(e)]
            }
        )

@router.post("/process", response_model=TaskResponse)
async def process(
    request: ProcessRequest,
    background_tasks: BackgroundTasks
):
    """
    Process conversations using crawl4ai for formatting, cleaning, and chunking.
    
    Args:
        request: Process request with conversation IDs and configuration
        background_tasks: FastAPI background tasks
        
    Returns:
        Task response with task ID and initial status
    """
    # Create a new task
    task_id = task_manager.create_task(
        "process", 
        {
            "conversation_ids": request.conversation_ids,
            "config": request.config.dict()
        }
    )
    
    # Start the processing task in the background
    background_tasks.add_task(
        _run_process_task,
        task_id=task_id,
        conversation_ids=request.conversation_ids,
        config=request.config.dict()
    )
    
    # Get the initial task status
    task = task_manager.get_task(task_id)
    
    return TaskResponse(
        task_id=task_id,
        status=task["status"],
        message=task["message"]
    )
