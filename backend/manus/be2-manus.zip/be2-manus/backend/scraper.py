"""
Total Recall - Conversation Scraper Module

This module handles the extraction of conversation history from ChatGPT
using the user's OpenAI token.
"""

import os
import json
import uuid
import asyncio
import logging
from datetime import datetime
from typing import Dict, List, Optional, Any
from playwright.async_api import async_playwright, Page, Browser

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
)
logger = logging.getLogger("total_recall.scraper")

# Constants
CHATGPT_URL = "https://chat.openai.com"
CONVERSATIONS_API = "https://chat.openai.com/backend-api/conversations"
CONVERSATION_DETAIL_API = "https://chat.openai.com/backend-api/conversation"
OUTPUT_DIR = "/home/ubuntu/total_recall/memory/conversations"

# Ensure output directory exists
os.makedirs(OUTPUT_DIR, exist_ok=True)


class ConversationScraper:
    """Handles scraping conversations from ChatGPT using the user's token."""

    def __init__(self, openai_token: str, date_filter: str = "pre_may_8_2025_only"):
        """
        Initialize the scraper with the user's OpenAI token.

        Args:
            openai_token: The user's OpenAI access token
            date_filter: Filter for conversations ("pre_may_8_2025_only" or "all_chats")
        """
        self.openai_token = openai_token
        self.date_filter = date_filter
        self.browser: Optional[Browser] = None
        self.page: Optional[Page] = None
        self.task_id = str(uuid.uuid4())
        self.status = {
            "task_id": self.task_id,
            "type": "scrape",
            "status": "pending",
            "progress": 0.0,
            "message": "Initializing scraper",
            "conversations_found": 0,
            "conversations_scraped": 0,
            "date_range": {
                "earliest": None,
                "latest": None
            },
            "files": [],
            "errors": [],
            "created_at": datetime.utcnow().isoformat(),
            "updated_at": datetime.utcnow().isoformat()
        }

    async def setup_browser(self) -> None:
        """Set up the browser and page for scraping."""
        try:
            playwright = await async_playwright().start()
            self.browser = await playwright.chromium.launch(headless=True)
            self.page = await self.browser.new_page()
            
            # Set the authorization token
            await self.page.context.add_cookies([{
                "name": "access_token",
                "value": self.openai_token,
                "domain": "chat.openai.com",
                "path": "/",
            }])
            
            self._update_status("in_progress", "Browser setup complete")
            logger.info("Browser setup complete")
        except Exception as e:
            self._update_status("failed", f"Browser setup failed: {str(e)}")
            logger.error(f"Browser setup failed: {str(e)}")
            raise

    async def get_conversation_list(self) -> List[Dict[str, Any]]:
        """
        Fetch the list of all conversations.
        
        Returns:
            List of conversation metadata
        """
        try:
            await self.page.goto(CHATGPT_URL)
            
            # Wait for the page to load
            await self.page.wait_for_load_state("networkidle")
            
            # Use the API to get conversations
            response = await self.page.evaluate(f"""
                async () => {{
                    const response = await fetch("{CONVERSATIONS_API}?offset=0&limit=100", {{
                        method: "GET",
                        headers: {{
                            "Content-Type": "application/json",
                            "Authorization": "Bearer {self.openai_token}"
                        }}
                    }});
                    return await response.json();
                }}
            """)
            
            conversations = response.get("items", [])
            total_count = response.get("total", 0)
            
            # If there are more conversations, fetch them in batches
            offset = 100
            while len(conversations) < total_count:
                self._update_status("in_progress", f"Fetching conversations {len(conversations)}/{total_count}")
                
                more_response = await self.page.evaluate(f"""
                    async () => {{
                        const response = await fetch("{CONVERSATIONS_API}?offset={offset}&limit=100", {{
                            method: "GET",
                            headers: {{
                                "Content-Type": "application/json",
                                "Authorization": "Bearer {self.openai_token}"
                            }}
                        }});
                        return await response.json();
                    }}
                """)
                
                more_conversations = more_response.get("items", [])
                if not more_conversations:
                    break
                    
                conversations.extend(more_conversations)
                offset += 100
            
            # Apply date filter if needed
            if self.date_filter == "pre_may_8_2025_only":
                cutoff_date = datetime.fromisoformat("2025-05-08T00:00:00")
                conversations = [
                    conv for conv in conversations 
                    if datetime.fromisoformat(conv.get("create_time", "2025-05-08T00:00:00")) < cutoff_date
                ]
            
            # Update status with conversation count
            self._update_status(
                "in_progress", 
                f"Found {len(conversations)} conversations matching filter"
            )
            self.status["conversations_found"] = len(conversations)
            
            # Update date range
            if conversations:
                create_times = [datetime.fromisoformat(conv.get("create_time", "2025-05-08T00:00:00")) 
                               for conv in conversations]
                self.status["date_range"]["earliest"] = min(create_times).isoformat()
                self.status["date_range"]["latest"] = max(create_times).isoformat()
            
            logger.info(f"Found {len(conversations)} conversations")
            return conversations
            
        except Exception as e:
            self._update_status("failed", f"Failed to fetch conversation list: {str(e)}")
            logger.error(f"Failed to fetch conversation list: {str(e)}")
            raise

    async def get_conversation_detail(self, conversation_id: str) -> Dict[str, Any]:
        """
        Fetch the details of a specific conversation.
        
        Args:
            conversation_id: ID of the conversation to fetch
            
        Returns:
            Conversation data with messages
        """
        try:
            # Use the API to get conversation details
            response = await self.page.evaluate(f"""
                async () => {{
                    const response = await fetch("{CONVERSATION_DETAIL_API}/{conversation_id}", {{
                        method: "GET",
                        headers: {{
                            "Content-Type": "application/json",
                            "Authorization": "Bearer {self.openai_token}"
                        }}
                    }});
                    return await response.json();
                }}
            """)
            
            return response
            
        except Exception as e:
            error_msg = f"Failed to fetch conversation {conversation_id}: {str(e)}"
            self.status["errors"].append(error_msg)
            logger.error(error_msg)
            return None

    def _format_conversation(self, conversation_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Format the conversation data into the required structure.
        
        Args:
            conversation_data: Raw conversation data from the API
            
        Returns:
            Formatted conversation data
        """
        # Extract basic metadata
        conversation_id = conversation_data.get("id", str(uuid.uuid4()))
        title = conversation_data.get("title", "Untitled Conversation")
        create_time = conversation_data.get("create_time", datetime.utcnow().isoformat())
        
        # Extract messages
        messages = []
        mapping = conversation_data.get("mapping", {})
        
        # Get the root message ID
        current_node_id = conversation_data.get("current_node")
        
        # Reconstruct the conversation by walking backwards from the current node
        message_path = []
        while current_node_id:
            node = mapping.get(current_node_id)
            if not node:
                break
                
            message_path.insert(0, current_node_id)
            current_node_id = node.get("parent")
        
        # Now process the messages in order
        for node_id in message_path:
            node = mapping.get(node_id)
            if not node:
                continue
                
            message = node.get("message")
            if not message:
                continue
                
            messages.append({
                "role": message.get("author", {}).get("role", "unknown"),
                "content": message.get("content", {}).get("parts", [""])[0]
            })
        
        # Extract any tags (if available)
        tags = []
        if "tags" in conversation_data:
            tags = conversation_data.get("tags", [])
        
        # Create the formatted conversation
        formatted_conversation = {
            "id": conversation_id,
            "title": title,
            "timestamp": create_time,
            "tags": tags,
            "conversation": messages
        }
        
        return formatted_conversation

    async def save_conversation(self, conversation: Dict[str, Any]) -> str:
        """
        Save a conversation to a JSON file.
        
        Args:
            conversation: Formatted conversation data
            
        Returns:
            Path to the saved file
        """
        try:
            # Create a safe filename from the conversation ID
            conversation_id = conversation["id"]
            filename = f"conversation_{conversation_id}.json"
            filepath = os.path.join(OUTPUT_DIR, filename)
            
            # Save the conversation to a JSON file
            with open(filepath, "w") as f:
                json.dump(conversation, f, indent=2)
            
            # Update status
            self.status["files"].append(filename)
            
            return filepath
            
        except Exception as e:
            error_msg = f"Failed to save conversation {conversation.get('id', 'unknown')}: {str(e)}"
            self.status["errors"].append(error_msg)
            logger.error(error_msg)
            return None

    async def scrape_conversations(self) -> Dict[str, Any]:
        """
        Scrape all conversations and save them to JSON files.
        
        Returns:
            Status of the scraping operation
        """
        try:
            # Set up the browser
            await self.setup_browser()
            
            # Get the list of conversations
            conversations = await self.get_conversation_list()
            
            # Process each conversation
            total_conversations = len(conversations)
            for i, conv_meta in enumerate(conversations):
                conversation_id = conv_meta.get("id")
                
                # Update status
                progress = (i + 1) / total_conversations if total_conversations > 0 else 1.0
                self._update_status(
                    "in_progress", 
                    f"Scraping conversation {i+1}/{total_conversations}: {conv_meta.get('title', 'Untitled')}"
                )
                self.status["progress"] = progress
                
                # Get conversation details
                conversation_data = await self.get_conversation_detail(conversation_id)
                
                if conversation_data:
                    # Format the conversation
                    formatted_conversation = self._format_conversation(conversation_data)
                    
                    # Save the conversation
                    await self.save_conversation(formatted_conversation)
                    
                    # Update count
                    self.status["conversations_scraped"] += 1
                
                # Small delay to avoid rate limiting
                await asyncio.sleep(0.5)
            
            # Update final status
            self._update_status(
                "completed", 
                f"Scraped {self.status['conversations_scraped']}/{total_conversations} conversations"
            )
            self.status["progress"] = 1.0
            
            # Clean up
            await self.cleanup()
            
            return self.status
            
        except Exception as e:
            self._update_status("failed", f"Scraping failed: {str(e)}")
            logger.error(f"Scraping failed: {str(e)}")
            
            # Clean up
            await self.cleanup()
            
            return self.status

    async def cleanup(self) -> None:
        """Clean up resources."""
        if self.browser:
            await self.browser.close()

    def _update_status(self, status: str, message: str) -> None:
        """
        Update the status of the scraping operation.
        
        Args:
            status: New status
            message: Status message
        """
        self.status["status"] = status
        self.status["message"] = message
        self.status["updated_at"] = datetime.utcnow().isoformat()
        logger.info(message)


async def scrape_conversations(openai_token: str, date_filter: str = "pre_may_8_2025_only") -> Dict[str, Any]:
    """
    Scrape conversations using the user's OpenAI token.
    
    Args:
        openai_token: The user's OpenAI access token
        date_filter: Filter for conversations ("pre_may_8_2025_only" or "all_chats")
        
    Returns:
        Status of the scraping operation
    """
    scraper = ConversationScraper(openai_token, date_filter)
    return await scraper.scrape_conversations()
