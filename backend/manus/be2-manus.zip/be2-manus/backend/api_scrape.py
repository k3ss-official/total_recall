"""
Total Recall - API Endpoints for Scraping

This module implements the /scrape endpoint for extracting conversation history
from ChatGPT using the user's OpenAI token.
"""

from fastapi import APIRouter, BackgroundTasks, Depends, HTTPException
from pydantic import BaseModel, Field
import asyncio
import logging
from typing import Optional, Dict, Any, List

from backend.scraper import scrape_conversations
from backend.task_manager import task_manager

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
)
logger = logging.getLogger("total_recall.api.scrape")

# Define router
router = APIRouter(tags=["scraping"])

# Request and response models
class ScrapeRequest(BaseModel):
    """Request model for the scrape endpoint."""
    openai_token: str = Field(..., description="User's OpenAI access token")
    date_filter: str = Field(
        "pre_may_8_2025_only", 
        description="Filter for conversations",
        pattern="^(pre_may_8_2025_only|all_chats)$"
    )

class TaskResponse(BaseModel):
    """Response model for task creation."""
    task_id: str = Field(..., description="Unique task identifier")
    status: str = Field(..., description="Task status")
    message: str = Field(..., description="Status message")

async def _run_scrape_task(task_id: str, openai_token: str, date_filter: str):
    """
    Background task to run the conversation scraper.
    
    Args:
        task_id: Task ID for status tracking
        openai_token: User's OpenAI access token
        date_filter: Filter for conversations
    """
    try:
        # Update task status to in_progress
        task_manager.update_task(
            task_id, 
            {
                "status": "in_progress",
                "message": "Starting conversation scraping"
            }
        )
        
        # Run the scraper
        status = await scrape_conversations(openai_token, date_filter)
        
        # Update task with scraper results
        task_manager.update_task(
            task_id,
            {
                "status": status["status"],
                "progress": status["progress"],
                "message": status["message"],
                "conversations_found": status.get("conversations_found", 0),
                "conversations_scraped": status.get("conversations_scraped", 0),
                "date_range": status.get("date_range", {"earliest": None, "latest": None}),
                "files": status.get("files", []),
                "errors": status.get("errors", [])
            }
        )
        
    except Exception as e:
        logger.error(f"Scrape task {task_id} failed: {str(e)}")
        task_manager.update_task(
            task_id,
            {
                "status": "failed",
                "message": f"Scraping failed: {str(e)}",
                "errors": [str(e)]
            }
        )

@router.post("/scrape", response_model=TaskResponse)
async def scrape(
    request: ScrapeRequest,
    background_tasks: BackgroundTasks
):
    """
    Extract conversation history from ChatGPT using the user's OpenAI token.
    
    Args:
        request: Scrape request with OpenAI token and date filter
        background_tasks: FastAPI background tasks
        
    Returns:
        Task response with task ID and initial status
    """
    # Create a new task
    task_id = task_manager.create_task(
        "scrape", 
        {
            "date_filter": request.date_filter
        }
    )
    
    # Start the scraping task in the background
    background_tasks.add_task(
        _run_scrape_task,
        task_id=task_id,
        openai_token=request.openai_token,
        date_filter=request.date_filter
    )
    
    # Get the initial task status
    task = task_manager.get_task(task_id)
    
    return TaskResponse(
        task_id=task_id,
        status=task["status"],
        message=task["message"]
    )
