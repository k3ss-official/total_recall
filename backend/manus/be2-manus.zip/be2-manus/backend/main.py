"""
Total Recall - Main FastAPI Application

This module sets up the main FastAPI application and includes all routers
for the backend API endpoints.
"""

from fastapi import FastAPI, Depends, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
import logging
import time
import os

# Import API routers
from backend.api_scrape import router as scrape_router
from backend.api_process import router as process_router
from backend.api_status import router as status_router

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
)
logger = logging.getLogger("total_recall.api")

# Create FastAPI app
app = FastAPI(
    title="Total Recall API",
    description="API for Total Recall - A tool to extract and inject ChatGPT conversations into persistent memory",
    version="1.0.0",
    docs_url="/api/docs",
    openapi_url="/api/openapi.json",
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # In production, restrict to specific origins
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Add request logging middleware
@app.middleware("http")
async def log_requests(request: Request, call_next):
    start_time = time.time()
    
    # Process the request
    response = await call_next(request)
    
    # Log request details
    process_time = time.time() - start_time
    logger.info(
        f"Request: {request.method} {request.url.path} - "
        f"Status: {response.status_code} - "
        f"Time: {process_time:.4f}s"
    )
    
    return response

# Include routers
app.include_router(scrape_router, prefix="/api")
app.include_router(process_router, prefix="/api")
app.include_router(status_router, prefix="/api")

# Root endpoint
@app.get("/")
async def root():
    return {
        "name": "Total Recall API",
        "version": "1.0.0",
        "status": "running",
        "documentation": "/api/docs"
    }

# Health check endpoint
@app.get("/health")
async def health_check():
    return {"status": "healthy"}

# Ensure required directories exist
os.makedirs("/home/ubuntu/total_recall/memory/conversations", exist_ok=True)
os.makedirs("/home/ubuntu/total_recall/memory/output_chunks", exist_ok=True)
