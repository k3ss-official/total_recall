"""
Total Recall - API Endpoints for Status Reporting

This module implements the /status endpoint for reporting on the state
of scraping and processing operations.
"""

from fastapi import APIRouter, Query, HTTPException
from pydantic import BaseModel, Field
import logging
from typing import Optional, Dict, Any, List

from backend.task_manager import task_manager

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
)
logger = logging.getLogger("total_recall.api.status")

# Define router
router = APIRouter(tags=["status"])

# Response models
class DateRange(BaseModel):
    """Date range for conversations."""
    earliest: Optional[str] = Field(None, description="Earliest conversation date")
    latest: Optional[str] = Field(None, description="Latest conversation date")

class ScrapeStatus(BaseModel):
    """Status of scraping operations."""
    status: str = Field(..., description="Current status")
    conversations_found: int = Field(0, description="Number of conversations found")
    conversations_scraped: int = Field(0, description="Number of conversations scraped")
    date_range: DateRange = Field(default_factory=DateRange)
    files: List[str] = Field(default_factory=list, description="List of saved conversation files")
    errors: List[str] = Field(default_factory=list, description="List of errors")

class ProcessStatus(BaseModel):
    """Status of processing operations."""
    status: str = Field(..., description="Current status")
    conversations_processed: int = Field(0, description="Number of conversations processed")
    chunks_created: int = Field(0, description="Number of chunks created")
    output_directory: Optional[str] = Field(None, description="Output directory for chunks")
    errors: List[str] = Field(default_factory=list, description="List of errors")

class Task(BaseModel):
    """Task details."""
    task_id: str = Field(..., description="Unique task identifier")
    type: str = Field(..., description="Task type")
    status: str = Field(..., description="Task status")
    progress: float = Field(..., description="Task progress (0.0 to 1.0)")
    message: str = Field(..., description="Status message")
    created_at: str = Field(..., description="Task creation timestamp")
    updated_at: str = Field(..., description="Task update timestamp")

class StatusResponse(BaseModel):
    """Response model for the status endpoint."""
    scrape: ScrapeStatus = Field(..., description="Scraping status")
    process: ProcessStatus = Field(..., description="Processing status")
    tasks: List[Task] = Field(..., description="List of tasks")

@router.get("/status", response_model=StatusResponse)
async def get_status(
    task_id: Optional[str] = Query(None, description="Filter by task ID"),
    task_type: Optional[str] = Query(None, description="Filter by task type")
):
    """
    Get the current state of scraping and processing operations.
    
    Args:
        task_id: Optional task ID to filter by
        task_type: Optional task type to filter by
        
    Returns:
        Status response with scrape and process state
    """
    # Get status summary from task manager
    status_summary = task_manager.get_status_summary()
    
    # If task_id is provided, filter tasks
    if task_id:
        task = task_manager.get_task(task_id)
        if not task:
            raise HTTPException(status_code=404, detail=f"Task {task_id} not found")
        
        status_summary["tasks"] = [task]
    
    # If task_type is provided, filter tasks
    elif task_type:
        if task_type not in ["scrape", "process"]:
            raise HTTPException(status_code=400, detail=f"Invalid task type: {task_type}")
        
        status_summary["tasks"] = task_manager.get_tasks(task_type)
    
    return StatusResponse(**status_summary)
