"""
Total Recall - Task Manager Module

This module handles background task management and status tracking
for scraping and processing operations.
"""

import uuid
from datetime import datetime
from typing import Dict, List, Any, Optional
import logging

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
)
logger = logging.getLogger("total_recall.task_manager")

class TaskManager:
    """Manages background tasks and tracks their status."""
    
    def __init__(self):
        """Initialize the task manager."""
        self.tasks: Dict[str, Dict[str, Any]] = {}
    
    def create_task(self, task_type: str, params: Dict[str, Any] = None) -> str:
        """
        Create a new task and return its ID.
        
        Args:
            task_type: Type of task ("scrape" or "process")
            params: Task parameters
            
        Returns:
            Task ID
        """
        task_id = str(uuid.uuid4())
        
        task = {
            "task_id": task_id,
            "type": task_type,
            "status": "pending",
            "progress": 0.0,
            "message": f"{task_type.capitalize()} task initialized",
            "params": params or {},
            "result": None,
            "errors": [],
            "created_at": datetime.utcnow().isoformat(),
            "updated_at": datetime.utcnow().isoformat()
        }
        
        # Add task-specific fields
        if task_type == "scrape":
            task.update({
                "conversations_found": 0,
                "conversations_scraped": 0,
                "date_range": {
                    "earliest": None,
                    "latest": None
                },
                "files": []
            })
        elif task_type == "process":
            task.update({
                "conversations_processed": 0,
                "chunks_created": 0,
                "output_directory": None
            })
        
        self.tasks[task_id] = task
        logger.info(f"Created {task_type} task with ID {task_id}")
        
        return task_id
    
    def update_task(self, task_id: str, updates: Dict[str, Any]) -> Dict[str, Any]:
        """
        Update a task's status and details.
        
        Args:
            task_id: ID of the task to update
            updates: Dictionary of fields to update
            
        Returns:
            Updated task data
            
        Raises:
            KeyError: If task_id is not found
        """
        if task_id not in self.tasks:
            raise KeyError(f"Task {task_id} not found")
        
        task = self.tasks[task_id]
        
        # Update fields
        for key, value in updates.items():
            if key in task:
                task[key] = value
        
        # Always update the updated_at timestamp
        task["updated_at"] = datetime.utcnow().isoformat()
        
        logger.info(f"Updated task {task_id}: {task['status']} - {task['message']}")
        
        return task
    
    def get_task(self, task_id: str) -> Optional[Dict[str, Any]]:
        """
        Get a task by ID.
        
        Args:
            task_id: ID of the task to retrieve
            
        Returns:
            Task data or None if not found
        """
        return self.tasks.get(task_id)
    
    def get_tasks(self, task_type: Optional[str] = None) -> List[Dict[str, Any]]:
        """
        Get all tasks, optionally filtered by type.
        
        Args:
            task_type: Optional filter by task type
            
        Returns:
            List of task data
        """
        if task_type:
            return [task for task in self.tasks.values() if task["type"] == task_type]
        return list(self.tasks.values())
    
    def get_status_summary(self) -> Dict[str, Any]:
        """
        Get a summary of all task statuses.
        
        Returns:
            Status summary
        """
        # Get the latest scrape task
        scrape_tasks = sorted(
            [task for task in self.tasks.values() if task["type"] == "scrape"],
            key=lambda x: x["created_at"],
            reverse=True
        )
        
        # Get the latest process task
        process_tasks = sorted(
            [task for task in self.tasks.values() if task["type"] == "process"],
            key=lambda x: x["created_at"],
            reverse=True
        )
        
        scrape_status = {
            "status": "not_started",
            "conversations_found": 0,
            "date_range": {
                "earliest": None,
                "latest": None
            },
            "files": [],
            "errors": []
        }
        
        if scrape_tasks:
            latest_scrape = scrape_tasks[0]
            scrape_status.update({
                "status": latest_scrape["status"],
                "conversations_found": latest_scrape.get("conversations_found", 0),
                "conversations_scraped": latest_scrape.get("conversations_scraped", 0),
                "date_range": latest_scrape.get("date_range", {"earliest": None, "latest": None}),
                "files": latest_scrape.get("files", []),
                "errors": latest_scrape.get("errors", [])
            })
        
        process_status = {
            "status": "not_started",
            "conversations_processed": 0,
            "chunks_created": 0,
            "output_directory": None,
            "errors": []
        }
        
        if process_tasks:
            latest_process = process_tasks[0]
            process_status.update({
                "status": latest_process["status"],
                "conversations_processed": latest_process.get("conversations_processed", 0),
                "chunks_created": latest_process.get("chunks_created", 0),
                "output_directory": latest_process.get("output_directory"),
                "errors": latest_process.get("errors", [])
            })
        
        return {
            "scrape": scrape_status,
            "process": process_status,
            "tasks": sorted(
                self.tasks.values(),
                key=lambda x: x["created_at"],
                reverse=True
            )
        }

# Create a global task manager instance
task_manager = TaskManager()
