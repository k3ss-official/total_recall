"""
Total Recall - Conversation Processor Module

This module handles the processing of conversations using crawl4ai
for formatting, cleaning, and chunking.
"""

import os
import json
import uuid
import asyncio
import logging
from datetime import datetime
from typing import Dict, List, Optional, Any
import yaml
from crawl4ai import Pipeline, Ingest, Transform, Chunk

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
)
logger = logging.getLogger("total_recall.processor")

# Constants
INPUT_DIR = "/home/ubuntu/total_recall/memory/conversations"
OUTPUT_DIR = "/home/ubuntu/total_recall/memory/output_chunks"
CONFIG_DIR = "/home/ubuntu/total_recall/backend/config"

# Ensure directories exist
os.makedirs(INPUT_DIR, exist_ok=True)
os.makedirs(OUTPUT_DIR, exist_ok=True)
os.makedirs(CONFIG_DIR, exist_ok=True)

# Create chat_clean.yaml if it doesn't exist
CHAT_CLEAN_YAML = os.path.join(CONFIG_DIR, "chat_clean.yaml")
if not os.path.exists(CHAT_CLEAN_YAML):
    with open(CHAT_CLEAN_YAML, "w") as f:
        yaml.dump({
            "transform": {
                "clean_steps": [
                    "remove_duplicate_whitespace",
                    "normalize_line_endings",
                    "trim_whitespace"
                ],
                "format_steps": [
                    "add_recall_markers",
                    "format_conversation_turns"
                ]
            }
        }, f)


class ConversationProcessor:
    """Handles processing conversations using crawl4ai."""

    def __init__(self, conversation_ids: List[str], config: Dict[str, Any]):
        """
        Initialize the processor with conversation IDs and configuration.

        Args:
            conversation_ids: List of conversation IDs to process
            config: Processing configuration
        """
        self.conversation_ids = conversation_ids
        self.config = config
        self.task_id = str(uuid.uuid4())
        self.status = {
            "task_id": self.task_id,
            "type": "process",
            "status": "pending",
            "progress": 0.0,
            "message": "Initializing processor",
            "conversations_processed": 0,
            "chunks_created": 0,
            "output_directory": OUTPUT_DIR,
            "errors": [],
            "created_at": datetime.utcnow().isoformat(),
            "updated_at": datetime.utcnow().isoformat()
        }

    async def setup_pipeline(self) -> Pipeline:
        """
        Set up the crawl4ai pipeline for processing.
        
        Returns:
            Configured crawl4ai pipeline
        """
        try:
            # Create ingest component
            ingest = Ingest(
                source_type="file",
                source_path=INPUT_DIR,
                file_pattern="conversation_*.json"
            )
            
            # Create transform component with chat_clean.yaml
            transform = Transform(
                config_file=CHAT_CLEAN_YAML,
                custom_formatters={
                    "add_recall_markers": self._add_recall_markers,
                    "format_conversation_turns": self._format_conversation_turns
                }
            )
            
            # Create chunk component
            chunk = Chunk(
                chunk_size=self.config.get("chunking", {}).get("chunk_size", 3900),
                chunk_overlap=self.config.get("chunking", {}).get("chunk_overlap", 100),
                chunk_strategy="token"
            )
            
            # Create and return the pipeline
            pipeline = Pipeline(
                name="total_recall_processor",
                components=[ingest, transform, chunk],
                output_dir=OUTPUT_DIR,
                output_format="json"
            )
            
            self._update_status("in_progress", "Pipeline setup complete")
            return pipeline
            
        except Exception as e:
            self._update_status("failed", f"Pipeline setup failed: {str(e)}")
            logger.error(f"Pipeline setup failed: {str(e)}")
            raise

    def _add_recall_markers(self, content: Dict[str, Any]) -> str:
        """
        Add recall markers to the conversation.
        
        Args:
            content: Conversation data
            
        Returns:
            Formatted content with recall markers
        """
        title = content.get("title", "Untitled Conversation")
        timestamp = content.get("timestamp", datetime.utcnow().isoformat())
        tags = content.get("tags", [])
        
        # Format tags as comma-separated string
        tags_str = ", ".join(tags) if tags else ""
        
        # Create the recall markers
        markers = f"""## RECALL MARKER START
Title: {title}
Date: {timestamp}
Tags: {tags_str}
## RECALL MARKER END

"""
        
        return markers

    def _format_conversation_turns(self, content: Dict[str, Any]) -> str:
        """
        Format the conversation turns.
        
        Args:
            content: Conversation data
            
        Returns:
            Formatted conversation turns
        """
        messages = content.get("conversation", [])
        
        # Format each message
        formatted_messages = []
        for message in messages:
            role = message.get("role", "unknown")
            content_text = message.get("content", "")
            
            # Capitalize the role for better readability
            role_display = role.capitalize()
            
            formatted_messages.append(f"{role_display}: {content_text}\n\n")
        
        return "".join(formatted_messages)

    async def process_conversations(self) -> Dict[str, Any]:
        """
        Process conversations using crawl4ai.
        
        Returns:
            Status of the processing operation
        """
        try:
            # Set up the pipeline
            pipeline = await self.setup_pipeline()
            
            # Filter conversations if specific IDs were provided
            if self.conversation_ids:
                # Create a list of file paths for the specified conversation IDs
                file_paths = [
                    os.path.join(INPUT_DIR, f"conversation_{conv_id}.json")
                    for conv_id in self.conversation_ids
                ]
                
                # Update the ingest component to use only these files
                pipeline.components[0].source_path = file_paths
            
            # Run the pipeline
            self._update_status("in_progress", "Running processing pipeline")
            
            # Process in batches to provide progress updates
            total_conversations = len(self.conversation_ids) if self.conversation_ids else len(
                [f for f in os.listdir(INPUT_DIR) if f.startswith("conversation_") and f.endswith(".json")]
            )
            
            processed_count = 0
            chunks_created = 0
            
            # Process each conversation
            for i, conv_id in enumerate(self.conversation_ids):
                file_path = os.path.join(INPUT_DIR, f"conversation_{conv_id}.json")
                
                if not os.path.exists(file_path):
                    self.status["errors"].append(f"Conversation file not found: {file_path}")
                    continue
                
                # Update status
                progress = (i + 1) / total_conversations if total_conversations > 0 else 1.0
                self._update_status(
                    "in_progress", 
                    f"Processing conversation {i+1}/{total_conversations}"
                )
                self.status["progress"] = progress
                
                # Process this conversation
                try:
                    # Load the conversation
                    with open(file_path, "r") as f:
                        conversation = json.load(f)
                    
                    # Apply the pipeline to this conversation
                    result = pipeline.process_item(conversation)
                    
                    # Count chunks created
                    chunks = result.get("chunks", [])
                    chunks_created += len(chunks)
                    
                    # Save chunks
                    for j, chunk in enumerate(chunks):
                        chunk_id = f"{conv_id}_chunk_{j}"
                        chunk_file = os.path.join(OUTPUT_DIR, f"{chunk_id}.json")
                        
                        with open(chunk_file, "w") as f:
                            json.dump({
                                "chunk_id": chunk_id,
                                "conversation_id": conv_id,
                                "metadata": {
                                    "title": conversation.get("title", "Untitled"),
                                    "date": conversation.get("timestamp"),
                                    "tags": conversation.get("tags", [])
                                },
                                "content": chunk,
                                "token_count": pipeline.components[2].get_token_count(chunk)
                            }, f, indent=2)
                    
                    processed_count += 1
                    
                except Exception as e:
                    error_msg = f"Failed to process conversation {conv_id}: {str(e)}"
                    self.status["errors"].append(error_msg)
                    logger.error(error_msg)
            
            # Update final status
            self._update_status(
                "completed", 
                f"Processed {processed_count}/{total_conversations} conversations, created {chunks_created} chunks"
            )
            self.status["progress"] = 1.0
            self.status["conversations_processed"] = processed_count
            self.status["chunks_created"] = chunks_created
            
            return self.status
            
        except Exception as e:
            self._update_status("failed", f"Processing failed: {str(e)}")
            logger.error(f"Processing failed: {str(e)}")
            return self.status

    def _update_status(self, status: str, message: str) -> None:
        """
        Update the status of the processing operation.
        
        Args:
            status: New status
            message: Status message
        """
        self.status["status"] = status
        self.status["message"] = message
        self.status["updated_at"] = datetime.utcnow().isoformat()
        logger.info(message)


async def process_conversations(conversation_ids: List[str], config: Dict[str, Any]) -> Dict[str, Any]:
    """
    Process conversations using crawl4ai.
    
    Args:
        conversation_ids: List of conversation IDs to process
        config: Processing configuration
        
    Returns:
        Status of the processing operation
    """
    processor = ConversationProcessor(conversation_ids, config)
    return await processor.process_conversations()
