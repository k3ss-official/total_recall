"""
Total Recall - API Validation Script

This script validates the backend API and processing pipeline end-to-end.
"""

import os
import sys
import json
import asyncio
import logging
from typing import Dict, Any, List
import httpx

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
)
logger = logging.getLogger("total_recall.validator")

# Constants
API_BASE_URL = "http://localhost:8000/api"
OPENAI_TOKEN = "YOUR_OPENAI_TOKEN"  # Replace with actual token for testing

async def test_scrape_endpoint() -> Dict[str, Any]:
    """
    Test the /scrape endpoint.
    
    Returns:
        Test results
    """
    logger.info("Testing /scrape endpoint...")
    
    async with httpx.AsyncClient() as client:
        try:
            # Make the request
            response = await client.post(
                f"{API_BASE_URL}/scrape",
                json={
                    "openai_token": OPENAI_TOKEN,
                    "date_filter": "pre_may_8_2025_only"
                }
            )
            
            # Check status code
            if response.status_code != 200:
                return {
                    "success": False,
                    "endpoint": "/scrape",
                    "status_code": response.status_code,
                    "error": f"Unexpected status code: {response.status_code}"
                }
            
            # Parse response
            data = response.json()
            
            # Check required fields
            required_fields = ["task_id", "status", "message"]
            for field in required_fields:
                if field not in data:
                    return {
                        "success": False,
                        "endpoint": "/scrape",
                        "status_code": response.status_code,
                        "error": f"Missing required field in response: {field}"
                    }
            
            return {
                "success": True,
                "endpoint": "/scrape",
                "status_code": response.status_code,
                "task_id": data["task_id"]
            }
            
        except Exception as e:
            return {
                "success": False,
                "endpoint": "/scrape",
                "error": f"Request failed: {str(e)}"
            }

async def test_process_endpoint(conversation_ids: List[str]) -> Dict[str, Any]:
    """
    Test the /process endpoint.
    
    Args:
        conversation_ids: List of conversation IDs to process
        
    Returns:
        Test results
    """
    logger.info("Testing /process endpoint...")
    
    async with httpx.AsyncClient() as client:
        try:
            # Make the request
            response = await client.post(
                f"{API_BASE_URL}/process",
                json={
                    "conversation_ids": conversation_ids,
                    "config": {
                        "chunking": {
                            "chunk_size": 3900,
                            "chunk_overlap": 100
                        },
                        "include_metadata": True,
                        "add_recall_markers": True
                    }
                }
            )
            
            # Check status code
            if response.status_code != 200:
                return {
                    "success": False,
                    "endpoint": "/process",
                    "status_code": response.status_code,
                    "error": f"Unexpected status code: {response.status_code}"
                }
            
            # Parse response
            data = response.json()
            
            # Check required fields
            required_fields = ["task_id", "status", "message"]
            for field in required_fields:
                if field not in data:
                    return {
                        "success": False,
                        "endpoint": "/process",
                        "status_code": response.status_code,
                        "error": f"Missing required field in response: {field}"
                    }
            
            return {
                "success": True,
                "endpoint": "/process",
                "status_code": response.status_code,
                "task_id": data["task_id"]
            }
            
        except Exception as e:
            return {
                "success": False,
                "endpoint": "/process",
                "error": f"Request failed: {str(e)}"
            }

async def test_status_endpoint(task_id: str = None) -> Dict[str, Any]:
    """
    Test the /status endpoint.
    
    Args:
        task_id: Optional task ID to filter by
        
    Returns:
        Test results
    """
    logger.info("Testing /status endpoint...")
    
    async with httpx.AsyncClient() as client:
        try:
            # Prepare URL
            url = f"{API_BASE_URL}/status"
            if task_id:
                url += f"?task_id={task_id}"
            
            # Make the request
            response = await client.get(url)
            
            # Check status code
            if response.status_code != 200:
                return {
                    "success": False,
                    "endpoint": "/status",
                    "status_code": response.status_code,
                    "error": f"Unexpected status code: {response.status_code}"
                }
            
            # Parse response
            data = response.json()
            
            # Check required fields
            required_fields = ["scrape", "process", "tasks"]
            for field in required_fields:
                if field not in data:
                    return {
                        "success": False,
                        "endpoint": "/status",
                        "status_code": response.status_code,
                        "error": f"Missing required field in response: {field}"
                    }
            
            return {
                "success": True,
                "endpoint": "/status",
                "status_code": response.status_code,
                "data": data
            }
            
        except Exception as e:
            return {
                "success": False,
                "endpoint": "/status",
                "error": f"Request failed: {str(e)}"
            }

async def validate_api_pipeline() -> Dict[str, Any]:
    """
    Validate the API and pipeline end-to-end.
    
    Returns:
        Validation results
    """
    results = {
        "endpoints": {},
        "overall_success": True
    }
    
    # Test /scrape endpoint
    scrape_result = await test_scrape_endpoint()
    results["endpoints"]["scrape"] = scrape_result
    
    if not scrape_result["success"]:
        results["overall_success"] = False
        return results
    
    # Wait for scraping to complete
    logger.info("Waiting for scraping to complete...")
    await asyncio.sleep(5)  # In a real test, would poll the status endpoint
    
    # Test /status endpoint for scrape task
    status_result = await test_status_endpoint(scrape_result["task_id"])
    results["endpoints"]["status_scrape"] = status_result
    
    if not status_result["success"]:
        results["overall_success"] = False
        return results
    
    # Get conversation IDs from status
    conversation_ids = []
    if "data" in status_result and "scrape" in status_result["data"]:
        files = status_result["data"]["scrape"].get("files", [])
        conversation_ids = [f.replace("conversation_", "").replace(".json", "") for f in files]
    
    # If no conversations, use dummy IDs for testing
    if not conversation_ids:
        conversation_ids = ["test_conversation_1", "test_conversation_2"]
    
    # Test /process endpoint
    process_result = await test_process_endpoint(conversation_ids[:2])  # Process first 2 conversations
    results["endpoints"]["process"] = process_result
    
    if not process_result["success"]:
        results["overall_success"] = False
        return results
    
    # Wait for processing to complete
    logger.info("Waiting for processing to complete...")
    await asyncio.sleep(5)  # In a real test, would poll the status endpoint
    
    # Test /status endpoint for process task
    status_process_result = await test_status_endpoint(process_result["task_id"])
    results["endpoints"]["status_process"] = status_process_result
    
    if not status_process_result["success"]:
        results["overall_success"] = False
    
    return results

async def main():
    """Main function."""
    logger.info("Starting API validation...")
    
    results = await validate_api_pipeline()
    
    # Print results
    print(json.dumps(results, indent=2))
    
    # Return success code
    return 0 if results["overall_success"] else 1

if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
