# Total Recall Backend API Implementation Report

## Overview

This report documents the implementation of the Total Recall backend API, which enables users to extract, process, and prepare their ChatGPT conversation history for injection into GPT-4o's persistent memory feature.

## Architecture

The backend API follows a modular, production-grade architecture with these key components:

1. **FastAPI Application** - Provides the HTTP interface for all endpoints
2. **Scraper Module** - Extracts conversation history using the user's OpenAI token
3. **Processing Pipeline** - Uses crawl4ai for conversation processing, formatting, and chunking
4. **Task Manager** - Tracks background tasks and provides status reporting
5. **Format Validator** - Ensures output chunks meet formatting requirements

## Implemented Endpoints

### 1. POST /api/scrape

Extracts the user's entire conversation history from ChatGPT.

**Request:**
```json
{
  "openai_token": "string",
  "date_filter": "pre_may_8_2025_only" | "all_chats"
}
```

**Response:**
```json
{
  "task_id": "string",
  "status": "pending",
  "message": "Scraping initiated"
}
```

**Implementation Details:**
- Uses browser automation via Playwright to extract conversations
- Saves each conversation as a separate JSON file with title, timestamp, tags, and messages
- Runs as a background task with real-time status updates
- Supports filtering for pre-May 8th, 2025 conversations

### 2. POST /api/process

Processes scraped conversations using crawl4ai for formatting, cleaning, and chunking.

**Request:**
```json
{
  "conversation_ids": ["string"],
  "config": {
    "chunking": {
      "chunk_size": 3900,
      "chunk_overlap": 100
    },
    "include_metadata": true,
    "add_recall_markers": true
  }
}
```

**Response:**
```json
{
  "task_id": "string",
  "status": "pending",
  "message": "Processing initiated"
}
```

**Implementation Details:**
- Uses crawl4ai for the processing pipeline
- Follows the ingest → transform → chunk workflow
- Uses chat_clean.yaml for formatting and cleanup
- Chunks conversations into ~3900-token segments
- Adds recall markers to formatted conversations
- Outputs per-chunk JSON files to /memory/output_chunks/

### 3. GET /api/status

Returns the current state of scraping and processing operations.

**Request Parameters:**
- `task_id` (optional): Specific task to check
- `task_type` (optional): Filter by task type ("scrape" or "process")

**Response:**
```json
{
  "scrape": {
    "status": "completed" | "in_progress" | "failed",
    "conversations_found": 120,
    "date_range": {
      "earliest": "2023-01-15T00:00:00Z",
      "latest": "2025-05-07T23:59:59Z"
    },
    "files": ["conversation_1.json", "conversation_2.json"],
    "errors": []
  },
  "process": {
    "status": "completed" | "in_progress" | "failed",
    "conversations_processed": 120,
    "chunks_created": 350,
    "output_directory": "/memory/output_chunks/",
    "errors": []
  },
  "tasks": [
    {
      "task_id": "string",
      "type": "scrape" | "process",
      "status": "pending" | "in_progress" | "completed" | "failed",
      "progress": 0.75,
      "message": "Processing conversation 90/120",
      "created_at": "2025-05-19T10:30:00Z",
      "updated_at": "2025-05-19T10:35:00Z"
    }
  ]
}
```

## Formatting Implementation

All processed conversations include recall markers as specified:

```markdown
## RECALL MARKER START
Title: Stock Oracle Research
Date: 2025-04-07T13:00:00Z
Tags: stock, ai, oracle
## RECALL MARKER END

User: What do you know about edge suppliers in the AI infra sector?
Assistant: Let's look at optical fiber vendors first...
```

The format validator ensures all chunks meet these requirements before they are made available for memory injection.

## Crawl4ai Integration

The processing pipeline uses crawl4ai for:

1. **Ingest** - Loading conversation JSON files from the conversations directory
2. **Transform** - Applying formatting and cleanup rules from chat_clean.yaml
3. **Chunk** - Splitting conversations into ~3900-token segments with metadata

The crawl4ai configuration is modular and can be adjusted through the API's configuration parameters.

## Directory Structure

```
/backend/
  ├── main.py                 # FastAPI application entry point
  ├── scraper.py              # Conversation scraper module
  ├── processor.py            # Conversation processor with crawl4ai
  ├── task_manager.py         # Background task tracking
  ├── validator.py            # Format validation
  ├── api_scrape.py           # /scrape endpoint implementation
  ├── api_process.py          # /process endpoint implementation
  ├── api_status.py           # /status endpoint implementation
  ├── validate_api.py         # End-to-end API validation
  └── config/
      └── chat_clean.yaml     # Crawl4ai configuration
```

## Running the API

To run the API:

1. Install dependencies:
   ```bash
   pip install --force-reinstall --no-cache-dir -r requirements.txt
   ```

2. Start the FastAPI server:
   ```bash
   uvicorn backend.main:app --host 0.0.0.0 --port 8000
   ```

3. Access the API documentation at:
   ```
   http://localhost:8000/api/docs
   ```

## Validation

The API includes a validation script (`validate_api.py`) that tests all endpoints end-to-end. This ensures:

1. The /scrape endpoint correctly extracts conversations
2. The /process endpoint correctly processes conversations with crawl4ai
3. The /status endpoint correctly reports on task progress
4. All output chunks meet the formatting requirements

## Next Steps

1. **UI Integration** - The backend API is ready for integration with the frontend UI
2. **Production Deployment** - Consider containerization for production deployment
3. **Performance Optimization** - For large conversation archives, consider batch processing optimizations

## Conclusion

The Total Recall backend API provides a robust, modular foundation for extracting, processing, and preparing ChatGPT conversation history for injection into GPT-4o's persistent memory feature. The implementation follows best practices for production-grade code, with comprehensive error handling, status reporting, and validation.
